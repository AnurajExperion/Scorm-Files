//Change the reseller name within double quotes
var bridgeURL = "http://tripletech.biz/bridge.php";

var resellerName = "";
//var resellerName = "debbie@blr.com";